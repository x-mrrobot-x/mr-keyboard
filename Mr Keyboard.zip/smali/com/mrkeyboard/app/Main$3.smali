.class Lcom/mrkeyboard/app/Main$3;
.super Ljava/lang/Object;
.source "Main.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mrkeyboard/app/Main;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/mrkeyboard/app/Main;

.field final synthetic val$that:Landroid/app/Activity;


# direct methods
.method constructor <init>(Lcom/mrkeyboard/app/Main;Landroid/app/Activity;)V
    .locals 0

    .line 69
    iput-object p1, p0, Lcom/mrkeyboard/app/Main$3;->this$0:Lcom/mrkeyboard/app/Main;

    iput-object p2, p0, Lcom/mrkeyboard/app/Main$3;->val$that:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    .line 71
    iget-object p1, p0, Lcom/mrkeyboard/app/Main$3;->this$0:Lcom/mrkeyboard/app/Main;

    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lcom/mrkeyboard/app/Main$3;->val$that:Landroid/app/Activity;

    const-class v2, Lcom/mrkeyboard/app/InputLanguageSelection;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Lcom/mrkeyboard/app/Main;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method
